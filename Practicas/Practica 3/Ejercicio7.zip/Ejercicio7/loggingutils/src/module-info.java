module loggingutils{
    requires java.logging;
    exports loggingutils;
}