module test{
    requires loggingutils;
}